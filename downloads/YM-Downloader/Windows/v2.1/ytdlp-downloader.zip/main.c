#define _WIN32_WINNT 0x0501
#define _WIN32_IE 0x0600

#include <windows.h>
#include <commctrl.h>
#include <shlobj.h>
#include <stdio.h>
#include <string.h>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "shell32.lib")

#define IDC_URL_EDIT 101
#define IDC_OUT_EDIT 102
#define IDC_BROWSE_BTN 103
#define IDC_FORMAT_COMBO 104
#define IDC_PLAYLIST_CHECK 105
#define IDC_DOWNLOAD_BTN 106
#define IDC_PROGRESS 107

#define YTDLP_PATH "yt-dlp.exe"
#define FFMPEG_PATH "."
#define MAX_PATH_LEN 512

typedef struct {
    HWND hUrlEdit;
    HWND hOutEdit;
    HWND hFormatCombo;
    HWND hPlaylistCheck;
    HWND hDownloadBtn;
    HWND hProgress;
    HWND hMainWnd;
} AppControls;

typedef struct {
    char url[1024];
    char outDir[MAX_PATH_LEN];
    char format[16];
    BOOL playlist;
    AppControls *controls;
} DownloadData;

void CleanupWebp(const char *outDir) {
    WIN32_FIND_DATA findData;
    HANDLE hFind;
    char searchPath[MAX_PATH_LEN];
    char filePath[MAX_PATH_LEN];
    
    snprintf(searchPath, sizeof(searchPath), "%s\\*.webp", outDir);
    
    hFind = FindFirstFile(searchPath, &findData);
    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            snprintf(filePath, sizeof(filePath), "%s\\%s", outDir, findData.cFileName);
            DeleteFile(filePath);
        } while (FindNextFile(hFind, &findData));
        FindClose(hFind);
    }
}

void CreateDirectoryRecursive(const char *path) {
    char temp[MAX_PATH_LEN];
    char *p;
    
    strncpy(temp, path, sizeof(temp) - 1);
    temp[sizeof(temp) - 1] = '\0';
    
    for (p = temp; *p; p++) {
        if (*p == '/' || *p == '\\') {
            char c = *p;
            *p = '\0';
            CreateDirectory(temp, NULL);
            *p = c;
        }
    }
    CreateDirectory(temp, NULL);
}

DWORD WINAPI DownloadThread(LPVOID lpParam) {
    DownloadData *dd = (DownloadData *)lpParam;
    char cmdLine[4096];
    char outputTemplate[MAX_PATH_LEN];
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    BOOL success;
    char errorMsg[512];
    
    // Build output template with proper escaping
    snprintf(outputTemplate, sizeof(outputTemplate), "%s\\%%(title)s.%%(ext)s", dd->outDir);
    
    // Build command line - note: no quotes around single words
    snprintf(cmdLine, sizeof(cmdLine),
        "%s %s --extractor-args youtube:player_client=android "
        "-f bestaudio/best --extract-audio --audio-format %s "
        "--audio-quality 0 --add-metadata "
        "--parse-metadata \"%(playlist_index|)s:%(track_number)s\" "
        "--parse-metadata \"%(album|)s:%(album)s\" "
        "--embed-thumbnail --write-thumbnail "
        "--ffmpeg-location \"%s\" "
        "--ignore-errors --no-warnings -o \"%s\" %s",
        YTDLP_PATH,
        dd->playlist ? "--yes-playlist" : "--no-playlist",
        dd->format,
        FFMPEG_PATH,
        outputTemplate,
        dd->url
    );
    
    // Initialize structures
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));
    
    // Create process - don't hide window for debugging
    success = CreateProcess(NULL, cmdLine, NULL, NULL, FALSE, 
                           0, NULL, NULL, &si, &pi);
    
    if (success) {
        // Wait for process to complete
        WaitForSingleObject(pi.hProcess, INFINITE);
        
        DWORD exitCode;
        GetExitCodeProcess(pi.hProcess, &exitCode);
        
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        
        // Cleanup webp files
        CleanupWebp(dd->outDir);
        
        // Update UI
        ShowWindow(dd->controls->hProgress, SW_HIDE);
        SendMessage(dd->controls->hProgress, PBM_SETPOS, 0, 0);
        EnableWindow(dd->controls->hDownloadBtn, TRUE);
        
        if (exitCode == 0) {
            MessageBox(dd->controls->hMainWnd, "Download completed successfully!", "Done", MB_OK | MB_ICONINFORMATION);
        } else {
            snprintf(errorMsg, sizeof(errorMsg), "yt-dlp exited with code: %lu\n\nMake sure:\n- yt-dlp.exe is in the same folder\n- The URL is valid\n- You have internet connection", exitCode);
            MessageBox(dd->controls->hMainWnd, errorMsg, "Error", MB_OK | MB_ICONERROR);
        }
    } else {
        DWORD err = GetLastError();
        ShowWindow(dd->controls->hProgress, SW_HIDE);
        SendMessage(dd->controls->hProgress, PBM_SETPOS, 0, 0);
        EnableWindow(dd->controls->hDownloadBtn, TRUE);
        
        snprintf(errorMsg, sizeof(errorMsg), 
                "Failed to start yt-dlp (Error code: %lu)\n\n"
                "Make sure yt-dlp.exe is in the same folder as this program.\n\n"
                "Command attempted:\n%s", err, cmdLine);
        MessageBox(dd->controls->hMainWnd, errorMsg, "Error", MB_OK | MB_ICONERROR);
    }
    
    free(dd);
    return 0;
}

void OnDownload(AppControls *controls) {
    char url[1024];
    char outDir[MAX_PATH_LEN];
    char format[16];
    int formatIdx;
    BOOL playlist;
    DownloadData *dd;
    HANDLE hThread;
    
    // Get URL
    GetWindowText(controls->hUrlEdit, url, sizeof(url));
    if (strlen(url) == 0) {
        MessageBox(controls->hMainWnd, "Please enter a YouTube URL", "Error", MB_OK | MB_ICONERROR);
        return;
    }
    
    // Get output directory
    GetWindowText(controls->hOutEdit, outDir, sizeof(outDir));
    if (strlen(outDir) == 0) {
        strcpy(outDir, ".");
    }
    
    // Get format
    formatIdx = SendMessage(controls->hFormatCombo, CB_GETCURSEL, 0, 0);
    switch (formatIdx) {
        case 0: strcpy(format, "mp3"); break;
        case 1: strcpy(format, "flac"); break;
        case 2: strcpy(format, "wav"); break;
        default: strcpy(format, "mp3"); break;
    }
    
    // Get playlist option
    playlist = SendMessage(controls->hPlaylistCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
    
    // Create output directory
    CreateDirectoryRecursive(outDir);
    
    // Allocate download data
    dd = (DownloadData *)malloc(sizeof(DownloadData));
    strncpy(dd->url, url, sizeof(dd->url) - 1);
    dd->url[sizeof(dd->url) - 1] = '\0';
    strncpy(dd->outDir, outDir, sizeof(dd->outDir) - 1);
    dd->outDir[sizeof(dd->outDir) - 1] = '\0';
    strncpy(dd->format, format, sizeof(dd->format) - 1);
    dd->format[sizeof(dd->format) - 1] = '\0';
    dd->playlist = playlist;
    dd->controls = controls;
    
    // Show progress and disable button
    ShowWindow(controls->hProgress, SW_SHOW);
    SendMessage(controls->hProgress, PBM_SETRANGE, 0, MAKELPARAM(0, 100));
    SendMessage(controls->hProgress, PBM_SETPOS, 50, 0);
    EnableWindow(controls->hDownloadBtn, FALSE);
    
    // Create download thread
    hThread = CreateThread(NULL, 0, DownloadThread, dd, 0, NULL);
    if (hThread) {
        CloseHandle(hThread);
    } else {
        ShowWindow(controls->hProgress, SW_HIDE);
        EnableWindow(controls->hDownloadBtn, TRUE);
        MessageBox(controls->hMainWnd, "Failed to create download thread", "Error", MB_OK | MB_ICONERROR);
        free(dd);
    }
}

void OnBrowse(AppControls *controls) {
    BROWSEINFO bi = {0};
    char path[MAX_PATH];
    LPITEMIDLIST pidl;
    
    bi.hwndOwner = controls->hMainWnd;
    bi.lpszTitle = "Select Output Directory";
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    
    pidl = SHBrowseForFolder(&bi);
    if (pidl != NULL) {
        if (SHGetPathFromIDList(pidl, path)) {
            SetWindowText(controls->hOutEdit, path);
        }
        CoTaskMemFree(pidl);
    }
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static AppControls controls;
    
    switch (msg) {
        case WM_CREATE: {
            controls.hMainWnd = hwnd;
            
            // URL label
            CreateWindow("STATIC", "YouTube / YouTube Music URL:", WS_VISIBLE | WS_CHILD,
                        10, 10, 400, 20, hwnd, NULL, NULL, NULL);
            
            // URL edit
            controls.hUrlEdit = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "",
                WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                10, 35, 460, 25, hwnd, (HMENU)IDC_URL_EDIT, NULL, NULL);
            
            // Output directory label
            CreateWindow("STATIC", "Output directory (optional):", WS_VISIBLE | WS_CHILD,
                        10, 70, 400, 20, hwnd, NULL, NULL, NULL);
            
            // Output edit
            controls.hOutEdit = CreateWindowEx(WS_EX_CLIENTEDGE, "EDIT", "",
                WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
                10, 95, 300, 25, hwnd, (HMENU)IDC_OUT_EDIT, NULL, NULL);
            
            // Browse button
            CreateWindow("BUTTON", "Browse",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                320, 95, 70, 25, hwnd, (HMENU)IDC_BROWSE_BTN, NULL, NULL);
            
            // Format combo box
            controls.hFormatCombo = CreateWindow("COMBOBOX", "",
                WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL,
                400, 95, 70, 100, hwnd, (HMENU)IDC_FORMAT_COMBO, NULL, NULL);
            SendMessage(controls.hFormatCombo, CB_ADDSTRING, 0, (LPARAM)"mp3");
            SendMessage(controls.hFormatCombo, CB_ADDSTRING, 0, (LPARAM)"flac");
            SendMessage(controls.hFormatCombo, CB_ADDSTRING, 0, (LPARAM)"wav");
            SendMessage(controls.hFormatCombo, CB_SETCURSEL, 0, 0);
            
            // Playlist checkbox
            controls.hPlaylistCheck = CreateWindow("BUTTON", "Allow playlist",
                WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
                10, 130, 150, 20, hwnd, (HMENU)IDC_PLAYLIST_CHECK, NULL, NULL);
            
            // Progress bar
            controls.hProgress = CreateWindowEx(0, PROGRESS_CLASS, NULL,
                WS_CHILD,
                10, 160, 460, 25, hwnd, (HMENU)IDC_PROGRESS, NULL, NULL);
            
            // Download button
            controls.hDownloadBtn = CreateWindow("BUTTON", "Download",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
                185, 195, 120, 30, hwnd, (HMENU)IDC_DOWNLOAD_BTN, NULL, NULL);
            
            break;
        }
        
        case WM_COMMAND:
            switch (LOWORD(wParam)) {
                case IDC_BROWSE_BTN:
                    OnBrowse(&controls);
                    break;
                case IDC_DOWNLOAD_BTN:
                    OnDownload(&controls);
                    break;
            }
            break;
        
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASSEX wc = {0};
    HWND hwnd;
    MSG msg;
    
    // Initialize common controls
    InitCommonControls();
    
    // Register window class
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = "YTDLPDownloader";
    
    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Window Registration Failed!", "Error", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }
    
    // Create window
    hwnd = CreateWindowEx(0, "YTDLPDownloader", "yt-dlp Audio Downloader",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 500, 280,
        NULL, NULL, hInstance, NULL);
    
    if (hwnd == NULL) {
        MessageBox(NULL, "Window Creation Failed!", "Error", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }
    
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
    
    // Message loop
    while (GetMessage(&msg, NULL, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    
    return msg.wParam;
}